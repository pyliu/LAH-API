<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: 'heir-share'
  }
</script>

<style>
  /* CSS */
</style>
